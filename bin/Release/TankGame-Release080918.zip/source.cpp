#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <string>
#include <cmath>
#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>

//See LICENSE.txt for copyright

//{DECLARATIONS

//{CONSTANTS & VARIABLES
const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 960;
const double PI = 3.14159265358979323846;

int mapwidth;
int mapheight;
double GRAVITY = 9.81;
int mouseX = 0;
int mouseY = 0;
double camX = 0;
double camY = 0;
bool LmouseState = 0;
bool LmouseClick = 0;
bool RmouseState = 0;
bool RmouseClick = 0;
SDL_Texture* loadTexture( std::string path );
SDL_Window* gWindow = NULL;
SDL_Renderer* gRenderer = NULL;
TTF_Font *gFont = NULL;
double gamespeed = 2;   //actual speed of game
double stepSize = 0.01; //speed of game - adjusted based on framerate
double mul = 2;     //scale of drawn graphics
double TICKS_PER_FRAME;
double MAX_FPS = 60;    //maximum framerate
double FPS = MAX_FPS;
double streakrenderres = 0.01;  //how accurately the streak left behind a projectile will be rendered close to a hit target - smaller = more accurate
bool slomo = false;
int physics = 1;
double scanangleincrement = 0.01; //increment when searching for a line of sight to a target
double circleres = 10;  //number of points generated in a circular shape
bool particleEffects = false;
bool pause = false;
const Uint8* keys = SDL_GetKeyboardState( NULL );
uint32_t frameCount = 0;
double traileffectprescision = 15;
uint32_t effectIDs = 0;
//bool damagefx = false;
//double walldrag = 0.9;
//}

//{STRUCTS
struct PercentRect{ //used for clipping images
	double x;
	double y;
	double w;
	double h;
};

struct ParticleLine{
    double x1;
    double y1;
    double x2;
    double y2;
    double r = 0xFF;
    double g = 0;
    double b = 0;
    double a = 0xFF;
    double t = 0;
    double dr = 0;
    double dg = 0;
    double db = 0;
    double da = -0.05;
    double dt = 0.05;
    uint32_t id=0;
};

struct Projectile{
    double x;
    double y;
    double xvel;
    double yvel;
    double angle;               //Angle of projectile in degrees
    int width;
    int length;
    SDL_Texture* look;          //visual look of projectile
    SDL_Rect clip;              //clip of look to be rendered
    double damage;

    double timer = 0x00;
    double m = 0;
    double c = 0;
    double tx = 0;              //origin of projectile
    double ty = 0;
    bool right = 0;

    ParticleLine traileffect;

    int dist=0;//steps travelled on current trail effect segment
    uint32_t lastid=0;
};

struct Shape{
    std::vector<double> x;
    std::vector<double> y;
};
//}

//{ENUMERATIONS
enum command { ACCELERATE, BRAKE, TURN, TURNTURRET, BRAKETURRET };
//}

//{CLASSES
class Tank{
	public:
        Tank();
		Tank(std::string, double, double, double);
		void positionReset(std::string, double, double, double, bool);
		~Tank();
		void step();
		void render();
		void free();
		void loadLook0();
		void loadLook(std::string, std::string, std::string, std::string, std::string, PercentRect*, PercentRect*, PercentRect*, PercentRect*, PercentRect*, SDL_Rect*, SDL_Rect*, SDL_Rect*, SDL_Rect*, SDL_Rect*);
		void setDimensions(double, double, double, double, double, double, double, double, double);
		void setOther(double, double, double, double);
		void setWeapons(double, double, double, double, int, int, double, double, int, int, ParticleLine, ParticleLine);
		bool primaryReloaded();
		bool secondaryReloaded();
		void setHealth(double, double, double, int);
		void takeDamage(double);
		bool isDead();
		double getLength();

				//commands
        void settargetvel(double);
        void pointTo(double, double);
        void shootPrimary(Projectile*);
        void shootSecondary(Projectile*);
		void accelerate(double);	//accelerate with power
		void brake(double);		//brake with force
		void turn(double);		//set power distribution between tracks (to steer)
				//accessors
        bool hasseentarget();
        double getHealth();
        double getMaxHealth();
        double getShield();
        double getMaxShield();
		double getX();			//get x position
		double getY();			//get y position
		double getXvel();
		double getYvel();
		double getVel();
		double getRot();		//get rotation of tank
		double getTurretrot();		//get rotation of turret
		int getPburst();    //projectiles fired per shot
		int getSburst();
		std::string getName();
		void setName(std::string);
		int getIndex();
		void setIndex(int);
		Shape getShape();
		void setIsCircle(bool);
		bool isACircle();
		int getPrimaryROF();     //reload time in game steps
		int getSecondaryROF();
		double getPrimaryReload();  //time spent reloading
		double getSecondaryReload();
	private:
				//graphics
		SDL_Texture* body;		//image of tank body
		SDL_Rect bodyclip;		//clip of body image file
		SDL_Texture* turret;		//image of turret
		SDL_Rect turretclip;		//clip of turret image file
		SDL_Texture* barrel;		//image of barrel
		SDL_Rect barrelclip;		//clip of barrel
		SDL_Texture* pproj;      //image of primary projectile
		SDL_Rect pprojclip;      //clip of primary projectile
		SDL_Texture* sproj;      //image of secondary projectile
		SDL_Rect sprojclip;      //clip of secondary projectile
				//position
		double x;			//x position
		double y;			//y position
		double xvel;			//x velocity
		double yvel;			//y velocity
		double vel;             //velocity
		double tankrot;			//rotation of tank
		//double tankrotvel;		//rotational velocity of tank
		double turretrot;		//rotation of turret relative to tank
		//double turretvel;		//rotational velocity of turret relative to tank
		double targetX = 0;
		double targetY = 0;
		Shape shape;
		double targetvel;
				//specs
					//mass
		double mass;			//mass of tank body
					//size
        bool iscircle = false;
		double length;			//length of body
		double width;			//width of body
		//double trackwidth;		//width of tracks
		double turretradius;		//radius of turret
		double barrellength;		//length of barrel
		double barrelwidth;		//width of barrel
		double pprojlength;
		double pprojwidth;
		double sprojlength;
		double sprojwidth;
					//other
		double power;			//power of engine (continous gearing is used)
		double brakeforce;		//force of brakes
		double maxvel;          //maximum velocity
                    //weapons
        double primaryDamage;
        double secondaryDamage;
		double primaryProjectileSpeed;
		double secondaryProjectileSpeed;
		int primaryROF;     //reload time in game steps
		int secondaryROF;
		double primaryReload;  //time spent reloading
		double secondaryReload;
		double pspread;
		double sspread;
		int pburst;
		int sburst;
		ParticleLine Peffect;
		ParticleLine Seffect;

        //health
        double maxHealth;
        double maxShield;
        double shieldRegen;
        int shieldDelay;
        double health;
        double shield;
        double shieldCount=0;
        bool dead=false;

        int index;  //index of tank in
        std::string name;
		double commands [5] = {0, 0, 0, 0, 0};		//array containing values of commands passed to tank
};
//}

//{METHODS
void init();
void loadMedia();
bool loadSettings(char*);
void loadTankTemplates(char*);
void loadTanks(char*);
void setMap(char*);
int* loadMap(std::vector<Shape*>*, char*);
uint8_t mainMenu();
void addButton(std::vector<Shape*>*, double, double, double, double);
uint8_t runGame();
void close();
bool updateMouse();
void handleInput(Tank*);	//Reads keyboard input, and sends controls to the Tank passed in
bool stepProjectile(Projectile*);
bool cansee(int, int, double*, double*);
double yfromx(double, double, double, double, double);
double yfromx(double, double, double, double, double);
void fire(bool, bool, Tank*, std::vector<Projectile*>*);
bool collision(int, double*, bool*);
bool passedovershape(double, double, double, double, Shape);
bool passedover(double, double, double, double, double, double, double, double);
void sortpoints(std::vector<double>*, std::vector<double>*);
bool isInShape(double, double, Shape);
double atan2(double, double, double, double);
bool checkcollision(Shape, Shape, double*, bool*);
int findSide(double, double, Shape);
double nearestpoint(double, double, double, double, double, double);
double distanceto(double, double, double, int, double, double);
void impactcoords(double, double, double, int, double, double, double*, double*);
int SCROLL_RenderDrawLine(SDL_Renderer*, int, int, int, int);
bool pauseMenu();

//}

//}

//{DEFINITIONS

//{TANK

void Tank::step(){
    if(!dead){
    bool gradset = false;
    bool* gradsetp = &gradset;
    double grad;
    double* collisiongrad = &grad;
    if(iscircle){
        double dist = sqrt((targetX-x)*(targetX-x) + (targetY-y)*(targetY-y));
        if(targetvel==0){
            if(dist < length/2 && vel > targetvel){
                vel = 0;
                commands[BRAKE] = 0;
                commands[ACCELERATE] = 0;
            }
        }else{
            if(dist < (length/2+50)){// && vel > targetvel){
                commands[BRAKE] = 100;
                commands[ACCELERATE] = 0;
            }
        }
    }
//    std::cout << x << " " << y << "\n";
//    AngleRect T = getAngleRect();
//    std::cout << "1: " << T.x1 << ", " << T.y1 << "\n";
//    std::cout << "2: " << T.x2 << ", " << T.y2 << "\n";
//    std::cout << "3: " << T.x3 << ", " << T.y3 << "\n";
//    std::cout << "4: " << T.x4 << ", " << T.y4 << "\n";
    if(primaryReload<primaryROF+1)
        primaryReload+=30*200.0*stepSize;
    if(secondaryReload<secondaryROF+1)
        secondaryReload+=30*200.0*stepSize;
    if(shieldCount<shieldDelay+3)
        shieldCount+=30*200.0*stepSize;
    if(shieldCount>shieldDelay)
        shield+=shieldRegen*stepSize;
    if(shield>maxShield)
        shield=maxShield;
    if(iscircle){
        tankrot = (atan((targetY - y)/(targetX - x))*180/PI);
        targetX < x ? tankrot += 180 : tankrot;
    }
    turretrot = (atan((targetY - y)/(targetX - x))*180/PI) - tankrot;
    targetX > x ? turretrot += 180 : turretrot;
    //std::cout << "TurretRot: " << turretrot << "\n";
    //std::cout << "TankRot:   " << tankrot << "\n";
//    std::cout << tankrot << "\n";
//    std::cout << "tankrot += " << commands[TURN] << " * " << stepSize << " * " << sqrt(abs(vel)+1) << " / 10;\n";
//	std::cout << "abs(vel)+1 = " << abs(vel)+1 << "\n";
//	std::cout << "vel = " << vel << "\n";
//    if(!iscircle)
//        std::cout << "tank" << index << "\ntankrot " << tankrot << "\nthing " << sqrt(fabs(vel)+1) << "\n";
	tankrot += commands[TURN] * stepSize * sqrt(fabs(vel)+1) / 10;
	if(collision(index, collisiongrad, gradsetp)){
        tankrot -= commands[TURN] * stepSize * sqrt(abs(vel)+1) / 10;
        std::cout << "Collision Detected...\n";
	}
	tankrot > 360 ? tankrot -= 360 : (tankrot < 0 ? tankrot += 360 : tankrot = tankrot);
//	double tankrottemp = tankrot;
//	tankrottemp > 360 ? tankrottemp -= 360 : (tankrottemp < 0 ? tankrottemp += 360 : tankrottemp = tankrottemp);
//    std::cout << tankrot << "\n";
	double tankrotrad = (tankrot) * PI / 180;    //convert from visual rotation to rotation for calculation
//	std::cout << "Rot: " << tankrot << "\nSin: " << sin(tankrotrad) << "\nCos: " << cos(tankrotrad) << "\n";
//	std::cout << tankrotrad << "\n";
	double usedpower = commands[ACCELERATE] * power / 100;  //calculate power used
	double drag = vel * vel / 10;   //drag so that tank can coast to a stop
	double braking = commands[BRAKE] * brakeforce / 100 + 10 + drag;   //strength of brakes being applied
	double thrust = usedpower / ( abs(vel) + 0.1 );	//calculate thrust at current velocity
	thrust > usedpower/10 ? thrust = usedpower/10 : thrust = thrust;
	thrust < usedpower/10 ? thrust = usedpower/10 : thrust = thrust;
	double dvel;
											//calculate acceleration provided to tracks by engine and brakes
	if( abs( thrust ) > braking ){							//tracks are powered by the engine
		vel > 0 ? thrust -= braking : thrust += braking;			//calculate net thrust
		dvel = stepSize * thrust / mass;				//calculate acceleration
	}else{										//tracks are braking
		thrust = braking - abs(thrust);						//calculate net braking
		vel > 0 ? dvel = -1 * stepSize * thrust / mass : dvel = stepSize * thrust / mass;				//calculate acceleration
	}
//	if(index!=0)
//        std::cout << thrust << "\n" << braking << "\n";
    vel += dvel;
    if(vel > maxvel)
        vel = maxvel;
    else if(fabs(vel) > maxvel)
        vel = -maxvel;
    xvel = cos(tankrotrad)*vel;
    yvel = sin(tankrotrad)*vel;
//    std::cout << tankrotrad << "\n";
    x+=stepSize*xvel;
    y+=stepSize*yvel;
    if(collision(index, collisiongrad, gradsetp)){
        //if(!iscircle || !gradset){
            y-=stepSize*yvel;
            x-=stepSize*xvel;
/*        } else {
//            std::cout << "COLLISION GRAD: " << grad << "\n";
            //SDL_Delay(5000);
            std::cout << "gradient: " << grad << "\n";
            if(!isinf){
                y-=sin(atan(grad))*vel*stepSize;
                x-=cos(atan(grad))*vel*stepSize;
            } else {
                y-=sin(tankrotrad)/abs(sin(tankrotrad))*vel*stepSize;
            }
            //y-=(yvel-xvel*grad)*stepSize;
            //x-=(xvel-yvel/grad)*stepSize;
//            y-=stepSize*yvel*walldrag;
//            x-=stepSize*xvel*walldrag;
            //vel*=walldrag;
//            tankrot = 180 * atan(grad) / PI;
        }*/
        bool solved = false;
        std::cout << "Collision Detected...\n";
        double maxangle;
        iscircle ? maxangle = PI : maxangle = PI/2.0;
        for(double i=0.1; i<maxangle; i+=0.1){
//            std::cout << "i: " << i << "\n";
            x+=stepSize*cos(tankrotrad+i)*vel;
            y+=stepSize*sin(tankrotrad+i)*vel;
            if(collision(index, collisiongrad, gradsetp)){
                x-=stepSize*cos(tankrotrad+i)*vel;
                y-=stepSize*sin(tankrotrad+i)*vel;
                x+=stepSize*cos(tankrotrad-i)*vel;
                y+=stepSize*sin(tankrotrad-i)*vel;
                if(collision(index, collisiongrad, gradsetp)){
                    x-=stepSize*cos(tankrotrad-i)*vel;
                    y-=stepSize*sin(tankrotrad-i)*vel;
                }else{
                    solved = true;
//                    std::cout << "i: " << i << "\ncos1: " << fabs(cos(tankrotrad-i)) << "\ncos2: " << fabs(cos(tankrotrad)) << "\n";
                    //SDL_Delay(1000);
/*                    if(tan(tankrotrad-i) > tan(tankrotrad)){
                    if(fabs(cos(tankrotrad-i)) > fabs(cos(tankrotrad))){
                        //std::cout << "val: " << stepSize*vel*(cos(tankrotrad-i)-cos(tankrotrad)) << "\n";
                        //SDL_Delay(100);
                        x-=stepSize*vel*(cos(tankrotrad-i)-cos(tankrotrad));
                        y-=stepSize*vel*(sin(tankrotrad-i)*(1-cos(tankrotrad)/cos(tankrotrad-i)));
                    }else if(fabs(sin(tankrotrad-i)) > fabs(sin(tankrotrad))){
                        y-=stepSize*vel*(sin(tankrotrad-i)-sin(tankrotrad));
                        x-=stepSize*vel*(cos(tankrotrad-i)*(1-sin(tankrotrad)/sin(tankrotrad-i)));
                    }*/
                    x-=stepSize*cos(tankrotrad-i)*vel*(1-cos(i))*(1-cos(i));
                    y-=stepSize*sin(tankrotrad-i)*vel*(1-cos(i))*(1-cos(i));
                    if(collision(index, collisiongrad, gradsetp)){
                        x+=stepSize*cos(tankrotrad-i)*vel*(1-cos(i))*(1-cos(i));
                        y+=stepSize*sin(tankrotrad-i)*vel*(1-cos(i))*(1-cos(i));
                    }
                    if(!iscircle)
                        vel*=sqrt(fabs(cos(i)));
                    i=PI;
                }
            }else{
                solved = true;
                /*if(fabs(cos(tankrotrad+i)) > fabs(cos(tankrotrad))){
                    x-=stepSize*vel*(cos(tankrotrad+i)-cos(tankrotrad));
                    y-=stepSize*vel*(sin(tankrotrad+i)*(1-cos(tankrotrad)/cos(tankrotrad+i)));
                }else if(fabs(sin(tankrotrad-i)) > fabs(sin(tankrotrad))){
                    y-=stepSize*vel*(sin(tankrotrad+i)-sin(tankrotrad));
                    x-=stepSize*vel*(cos(tankrotrad+i)*(1-sin(tankrotrad)/sin(tankrotrad+i)));
                }*/
                x-=stepSize*cos(tankrotrad+i)*vel*(1-cos(i))*(1-cos(i));
                y-=stepSize*sin(tankrotrad+i)*vel*(1-cos(i))*(1-cos(i));
                if(collision(index, collisiongrad, gradsetp)){
                    x+=stepSize*cos(tankrotrad+i)*vel*(1-cos(i))*(1-cos(i));
                    y+=stepSize*sin(tankrotrad+i)*vel*(1-cos(i))*(1-cos(i));
                }
                if(!iscircle)
                    vel*=sqrt(fabs(cos(i)));
                i=PI;
            }
        }
        if(!solved)
            vel/=2;
	}
//	std::cout << x << " " << y << "\n";
//	std::cout << "Thrust:   " << thrust << "\n";
//	std::cout << "Velocity: " << vel << "\n";
//    std::cout << "X Vel:    " << xvel << "\n";
//	std::cout << "Y Vel:    " << yvel << "\n";
//	std::cout << "X coord:  " << x << "\n";
//	std::cout << "Y coord:  " << y << "\n";
}}

void Tank::pointTo(double targx, double targy){
    targetX = targx;
    targetY = targy;
}

void Tank::shootPrimary(Projectile* p){
    primaryReload = 0;
    p->x = x-cos((tankrot+turretrot)*PI/180)*mul*(turretradius + barrellength)/2;
    p->y = y-sin((tankrot+turretrot)*PI/180)*mul*(turretradius + barrellength)/2;
    p->angle = turretrot+tankrot;
    if(pspread>0)
        p->angle += ((rand()%1000)*1.0)/(500/(pspread)) - pspread;
    p->xvel = xvel-cos(p->angle*PI/180)*primaryProjectileSpeed;
    p->yvel = yvel-sin(p->angle*PI/180)*primaryProjectileSpeed;
    p->width = pprojwidth;
    p->length = pprojlength;
    p->look = pproj;
    p->clip = pprojclip;

    p->m = (targetY - y)/(targetX - x);
    p->c = y - p->m*x;
    p->tx = p->x;//-cos((tankrot+turretrot)*PI/180)*mul*(turretradius + barrellength)/2;
    p->ty = p->y;//-sin((tankrot+turretrot)*PI/180)*mul*(turretradius + barrellength)/2;
    p->tx > targetX ? p->right = 0 : p->right = 1;
    p->traileffect = Peffect;
    p->damage = primaryDamage;
}

void Tank::shootSecondary(Projectile* p){
    secondaryReload = 0;
    p->x = x-cos((tankrot+turretrot)*PI/180)*mul*(turretradius + barrellength)/2;
    p->y = y-sin((tankrot+turretrot)*PI/180)*mul*(turretradius + barrellength)/2;
    p->angle = turretrot+tankrot;
    if(sspread>0)
        p->angle += ((rand()%1000)*1.0)/(500/(sspread)) - sspread;
    p->xvel = xvel-cos(p->angle*PI/180)*secondaryProjectileSpeed;
    p->yvel = yvel-sin(p->angle*PI/180)*secondaryProjectileSpeed;

    p->width = sprojwidth;
    p->length = sprojlength;
    p->look = sproj;
    p->clip = sprojclip;

    p->m = /*(targetY - y)/(targetX - x) +*/ tan(p->angle*PI/180);
    p->c = y - p->m*x;
    p->tx = p->x;//-cos((p->angle)*PI/180)*mul*(turretradius + barrellength)/2;
    p->ty = p->y;//-sin((p->angle)*PI/180)*mul*(turretradius + barrellength)/2;
    p->tx > targetX ? p->right = 0 : p->right = 1;
    p->traileffect = Seffect;
    p->damage = secondaryDamage;
}

Tank::Tank(){};

Tank::Tank(std::string nname, double xpos, double ypos, double rot){
    if(nname==""){
        nname="unnamed";
    }
	positionReset(nname, xpos, ypos, rot, true);
}

void Tank::positionReset(std::string nname, double xpos, double ypos, double rot, bool reset){
	if(nname!="")
        name = nname;
	if(xpos>=0)
        x = xpos;
	if(ypos>=0)
        y = ypos;
	if(rot>=0)
        tankrot = rot;
    if(reset){
        turretrot = 0;
        xvel = 0;
        yvel = 0;
        vel = 0;
	}
}

Tank::~Tank(){
	//free();
}

void Tank::setOther(double npower, double nbrakeforce, double nmaxvel, double nmass){
	if( npower > 0 )
		power = npower;
	if( nbrakeforce > 0 )
		brakeforce = nbrakeforce;
	if( nmaxvel > 0 )
        maxvel = nmaxvel;
    if( nmass > 0)
        mass = nmass;
}

void Tank::setWeapons(double nPdamage, double nSdamage, double nPprojectileSpeed, double nSprojectileSpeed, int nprimaryROF, int nsecondaryROF, double npspread, double nsspread, int npburst, int nsburst, ParticleLine nPeffect, ParticleLine nSeffect){
    if( nPprojectileSpeed > 0 )
        primaryProjectileSpeed = nPprojectileSpeed;
    if( nSprojectileSpeed > 0 )
        secondaryProjectileSpeed = nSprojectileSpeed;
    if( nprimaryROF > 0 )
        primaryROF = nprimaryROF;
    if( nsecondaryROF > 0 )
        secondaryROF = nsecondaryROF;
    primaryReload = primaryROF;
    secondaryReload = secondaryROF;
    pspread = npspread;
    sspread = nsspread;
    if( npburst > 0)
        pburst = npburst;
    if( nsburst > 0)
        sburst = nsburst;
    Peffect = nPeffect;
    Seffect = nSeffect;
    primaryDamage=nPdamage;
    secondaryDamage=nSdamage;
}

void Tank::setDimensions(double nlength, double nwidth, double nturretradius, double nbarrellength, double nbarrelwidth, double npprojlength, double npprojwidth, double nsprojlength, double nsprojwidth){
	if( nlength != 0 )
		length = nlength*mul;
	if( nwidth != 0 )
		width = nwidth*mul;
	if( nturretradius != 0 )
		turretradius = nturretradius*mul;
	if( nbarrellength != 0 )
		barrellength = nbarrellength*mul;
	if( nbarrelwidth != 0 )
		barrelwidth = nbarrelwidth*mul;
    if( npprojlength != 0 )
        pprojlength = npprojlength*mul;
    if( npprojwidth != 0 )
        pprojwidth = npprojwidth*mul;
    if( nsprojlength != 0 )
        sprojlength = nsprojlength*mul;
    if( nsprojwidth != 0 )
        sprojwidth = nsprojwidth*mul;
}

void Tank::setHealth(double nmaxHealth, double nmaxShield, double nshieldRegen, int nshieldDelay){
    maxHealth=nmaxHealth;
    maxShield=nmaxShield;
    shieldRegen=nshieldRegen;
    shieldDelay=nshieldDelay;
    health=maxHealth;
    shield=maxShield;
}

void Tank::free(){
    //Causes segfaults
	if(body!=NULL){
		SDL_DestroyTexture(body);
	}
	if(turret!=NULL){
		SDL_DestroyTexture(turret);
	}
	if(barrel!=NULL){
		SDL_DestroyTexture(barrel);
    }
    if(pproj!=NULL){
        SDL_DestroyTexture(pproj);
    }
    if(sproj!=NULL){
        SDL_DestroyTexture(sproj);
    }
}

void Tank::loadLook0(){
    loadLook("data/graphics/body.png", "data/graphics/turret.png", "data/graphics/barrel.png", "data/graphics/primaryprojectile.png", "data/graphics/secondaryprojectile.png", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
}

void Tank::loadLook(std::string bodypath = "data/graphics/body.png", std::string turretpath = "data/graphics/turret.png", std::string barrelpath = "data/graphics/barrel.png", std::string pprojpath = "data/graphics/projectile.png", std::string sprojpath = "data/graphics/secondaryprojectile.png", PercentRect* bodysource = NULL, PercentRect* turretsource = NULL, PercentRect* barrelsource = NULL, PercentRect* pprojsource = NULL, PercentRect* sprojsource = NULL, SDL_Rect* bodystretchn = NULL, SDL_Rect* turretstretchn = NULL, SDL_Rect* barrelstretchn = NULL, SDL_Rect* pprojstretchn = NULL, SDL_Rect* sprojstretchn = NULL){
	//free();

	SDL_Surface* bodyimage = IMG_Load( bodypath.c_str() );						//Load images
	SDL_Surface* turretimage = IMG_Load( turretpath.c_str() );
	SDL_Surface* barrelimage = IMG_Load( barrelpath.c_str() );
	SDL_Surface* pprojimage = IMG_Load( pprojpath.c_str() );
	SDL_Surface* sprojimage = IMG_Load( sprojpath.c_str() );

	SDL_SetColorKey( bodyimage, SDL_TRUE, SDL_MapRGB( bodyimage->format, 0xFF, 0xFF, 0xFF ) );	//Colour key loaded images
	SDL_SetColorKey( turretimage, SDL_TRUE, SDL_MapRGB( turretimage->format, 0xFF, 0xFF, 0xFF ) );
	SDL_SetColorKey( barrelimage, SDL_TRUE, SDL_MapRGB( barrelimage->format, 0xFF, 0xFF, 0xFF ) );
	SDL_SetColorKey( pprojimage, SDL_TRUE, SDL_MapRGB( pprojimage->format, 0xFF, 0xFF, 0xFF ) );
	SDL_SetColorKey( sprojimage, SDL_TRUE, SDL_MapRGB( sprojimage->format, 0xFF, 0xFF, 0xFF ) );

	body = SDL_CreateTextureFromSurface( gRenderer, bodyimage );					//Create texture
	turret = SDL_CreateTextureFromSurface( gRenderer, turretimage );
	barrel = SDL_CreateTextureFromSurface( gRenderer, barrelimage );
	pproj = SDL_CreateTextureFromSurface( gRenderer, pprojimage );
	sproj = SDL_CreateTextureFromSurface( gRenderer, sprojimage );

	if( bodysource == NULL ){									//Prepare rectangles for clipping textures
		SDL_Rect temp = {0, 0, bodyimage->w, bodyimage->h};
		bodyclip = temp;
	}else{
		bodyclip.w = bodyimage->w * bodysource->w / 100;
		bodyclip.h = bodyimage->h * bodysource->h / 100;
		bodyclip.x = bodyimage->w * bodysource->x / 100;
		bodyclip.y = bodyimage->h * bodysource->y / 100;
	}
	if( turretsource == NULL ){
		SDL_Rect temp = {0, 0, turretimage->w, turretimage->h};
		turretclip = temp;
	}else{
		turretclip.w = turretimage->w * turretsource->w / 100;
		turretclip.h = turretimage->h * turretsource->h / 100;
		turretclip.x = turretimage->w * turretsource->x / 100;
		turretclip.y = turretimage->h * turretsource->y / 100;
	}
	if( barrelsource == NULL ){
		SDL_Rect temp = {0, 0, barrelimage->w, barrelimage->h};
		barrelclip = temp;
	}else{
		barrelclip.w = barrelimage->w * barrelsource->w / 100;
		barrelclip.h = barrelimage->h * barrelsource->h / 100;
		barrelclip.x = barrelimage->w * barrelsource->x / 100;
		barrelclip.y = barrelimage->h * barrelsource->y / 100;
	}
	if( pprojsource == NULL ){
		SDL_Rect temp = {0, 0, pprojimage->w, pprojimage->h};
		pprojclip = temp;
	}else{
		pprojclip.w = pprojimage->w * pprojsource->w / 100;
		pprojclip.h = pprojimage->h * pprojsource->h / 100;
		pprojclip.x = pprojimage->w * pprojsource->x / 100;
		pprojclip.y = pprojimage->h * pprojsource->y / 100;
	}

	if( sprojsource == NULL ){
		SDL_Rect temp = {0, 0, sprojimage->w, sprojimage->h};
		sprojclip = temp;
	}else{
		sprojclip.w = sprojimage->w * sprojsource->w / 100;
		sprojclip.h = sprojimage->h * sprojsource->h / 100;
		sprojclip.x = sprojimage->w * sprojsource->x / 100;
		sprojclip.y = sprojimage->h * sprojsource->y / 100;
	}

	SDL_FreeSurface( bodyimage );									//Free surfaces
	SDL_FreeSurface( turretimage );
	SDL_FreeSurface( barrelimage );
	SDL_FreeSurface( pprojimage );
	SDL_FreeSurface( sprojimage );
}

void Tank::render(){											//Render tank at current position with set dimentions
	SDL_Rect temp = {x-width/2-camX, y-length/2-camY, width, length};						//x-width/2 is used, so that the x and y coordinates refer to the center of the tank
	SDL_RenderCopyEx( gRenderer, body, &bodyclip, &temp, tankrot+90, NULL, SDL_FLIP_NONE);

	temp = {x-turretradius-camX, y-turretradius-camY, turretradius*2, turretradius*2};
	SDL_RenderCopyEx( gRenderer, turret, &turretclip, &temp, tankrot+turretrot+90, NULL, SDL_FLIP_NONE);

	SDL_Point center = {barrelwidth/2, 1-turretradius};
	temp = {x-barrelwidth/2-camX, y+turretradius-camY, barrelwidth, barrellength};
	SDL_RenderCopyEx( gRenderer, barrel, &barrelclip, &temp, tankrot+turretrot+90, &center, SDL_FLIP_NONE);
}

void Tank::takeDamage(double damage){
    if(shield>0)
        shieldCount=0;
    if(shield>damage)
        shield-=damage;
    else{
        damage-=shield;
        shield=0;
        if(health>damage)
            health-=damage;
        else{
            dead=true;
            health=0;
        }    //call death animation
    }
}

//{those methods

int Tank::getPrimaryROF(){     //reload time in game steps
    return primaryROF;
}
int Tank::getSecondaryROF(){
    return secondaryROF;
}
double Tank::getPrimaryReload(){  //time spent reloading
    return primaryReload;
}
double Tank::getSecondaryReload(){
    return secondaryReload;
}

double Tank::getLength(){
    return length;
}

bool Tank::isDead(){
    return dead;
}

double Tank::getHealth(){
    return health;
}
double Tank::getMaxHealth(){
    return maxHealth;
}
double Tank::getShield(){
    return shield;
}
double Tank::getMaxShield(){
    return maxShield;
}

bool Tank::hasseentarget(){
    return targetX!=0 && targetY!=0;
}

void Tank::settargetvel(double n){
    targetvel = n;
}

double Tank::getVel(){
    return vel;
}

int Tank::getIndex(){
    return index;
}

void Tank::setIndex(int i){
    index = i;
}

std::string Tank::getName(){
    return name;
}

void Tank::setName(std::string nname){
    name = nname;
}

void Tank::setIsCircle(bool n){
    iscircle = n;
}

bool Tank::isACircle(void){
    return iscircle;
}

Shape Tank::getShape(){
//    std::cout << "fuckme\n";
    Shape temp;
    std::vector<double> xvec;
    std::vector<double> yvec;
    if(!iscircle){
//    std::cout << "notacircle\n";
    double tankrotrad = tankrot * PI / 180;
//    std::cout << "vel " << vel << "\nx " << x << "\ntankrot " << tankrot << "\ntankrotrad " << tankrotrad << "\nlength " << length << "\nwidth" << width << "\n";
    xvec.push_back(x+cos(tankrotrad)*length/2+sin(tankrotrad)*width/2);    //front left
    yvec.push_back(y+sin(tankrotrad)*length/2-cos(tankrotrad)*width/2);
//    std::cout << "xso " << x+cos(tankrotrad)*length/2+sin(tankrotrad)*width/2 << "\n";
    xvec.push_back(x+cos(tankrotrad)*length/2-sin(tankrotrad)*width/2);    //front right
    yvec.push_back(y+sin(tankrotrad)*length/2+cos(tankrotrad)*width/2);
//    std::cout << "xso " << xvec.at(xvec.size()-1) << "\n";
    xvec.push_back(x-cos(tankrotrad)*length/2+sin(tankrotrad)*width/2);    //back left
    yvec.push_back(y-sin(tankrotrad)*length/2-cos(tankrotrad)*width/2);
//    std::cout << "xso " << xvec.at(xvec.size()-1) << "\n";
    xvec.push_back(x-cos(tankrotrad)*length/2-sin(tankrotrad)*width/2);    //back right
    yvec.push_back(y-sin(tankrotrad)*length/2+cos(tankrotrad)*width/2);
//    std::cout << "xso " << xvec.at(xvec.size()-1) << "\n";
    }else{
//    std::cout << "isacircle\n";
    for(double i = 0; i<1; i+=1.0/circleres){
        xvec.push_back(x + cos(2*PI*i)*length/2);
        yvec.push_back(y + sin(2*PI*i)*length/2);
    }
    }
//    std::cout << "FFUU";
    sortpoints(&xvec, &yvec);
//    std::cout << "CCKK\n";
    temp.x = xvec;
    temp.y = yvec;
    return temp;
}

int Tank::getPburst(){
    return pburst;
}

int Tank::getSburst(){
    return sburst;
}

double Tank::getX(){
	return x;
}

double Tank::getY(){
	return y;
}

double Tank::getXvel(){
    return xvel;
}

double Tank::getYvel(){
    return yvel;
}

double Tank::getRot(){
	return tankrot;
}

double Tank::getTurretrot(){
	return turretrot;
}

void Tank::accelerate(double percent = 100){
	commands[ACCELERATE] = percent;
}

void Tank::brake(double percent = 100){
	commands[BRAKE] = percent;
}

void Tank::turn(double diff = 0){
	commands[TURN] = diff;
}

bool Tank::primaryReloaded(){
    return primaryReload > primaryROF;
}

bool Tank::secondaryReloaded(){
    return secondaryReload > secondaryROF;
}
//}
//}

//{METHODS
void init(){
	SDL_Init( SDL_INIT_VIDEO );
	SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" );
	gWindow = SDL_CreateWindow( "Game", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
	gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
	SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
	IMG_Init( IMG_INIT_PNG );
	SDL_SetRenderDrawBlendMode(gRenderer, SDL_BLENDMODE_BLEND);
    TTF_Init();
	TICKS_PER_FRAME = 1000/MAX_FPS;
	stepSize = gamespeed/(MAX_FPS*physics);

	gFont = TTF_OpenFont( "data/graphics/font.ttf", 28 );
	if( gFont == NULL ){
        std::cout << "error\n";
        std::cout << TTF_GetError();
        printf( "Failed to load lazy font! SDL_ttf Error: %s\n", TTF_GetError() );
        SDL_Delay(10000);
    }

}

void close(){
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;
	IMG_Quit();
	SDL_Quit();
}

std::vector<Tank*> tanks;
std::vector<Tank> tankTemplates;
std::vector<Shape*> shapes;
std::vector<ParticleLine> particlelines;

int main( int argc, char* args[] ){
	init();
	uint8_t option = 1;
	if(loadSettings("data/game/settings.txt")){//if no menu skip, show menu
        loadTankTemplates("data/game/tanktemplates.txt");
        loadTanks("data/game/tanks.txt");
        setMap("data/game/map1.txt");
        runGame();
        close();
        return 0;
    }
    while(true){
        switch (option){
            case 0:
                close();
                return 0;
            break;
            case 1:
                option = mainMenu();
            break;
            case 2:
                option = runGame();
            break;
        }
    }
	close();
	return 0;
}

uint8_t runGame(){
    uint32_t frameTimer;
	bool quit = false;
	SDL_Event e;
    std::vector<Projectile*> projectiles;
    std::vector<uint32_t> frames;
    for(double i=0; i<1000; i+=1000/MAX_FPS){
        frames.push_back(SDL_GetTicks()-1000+i);
    }
    uint32_t lastpause = 0;
    uint32_t pauseduration = 0;
    bool recentpause = false;

	while( !quit ){      //DONT FORGET - NEEDS TO BE !quit
        frameTimer = SDL_GetTicks();
        Shape* t = shapes[1];
        //{Calculate FPS
        frames.push_back(SDL_GetTicks());
        for(int i=0;i<frames.size();i++){
            if(frames[i] + 1000 < SDL_GetTicks()){
                if(recentpause){
                    if(SDL_GetTicks()-lastpause<1000){//check again if recently paused
                        if(frames[i]+1000+pauseduration<SDL_GetTicks())
                            frames.erase(frames.begin()+i);
                    }else{
                        recentpause=false;
                        frames.erase(frames.begin()+i);
                    }
                }else{
                    frames.erase(frames.begin()+i);
                }
            }
        }
        FPS = frames.size();
        stepSize = gamespeed/(FPS*physics);
        if(slomo)
            stepSize/=16;
//        if(false)
//            particleEffects=false;
//        else
//            particleEffects=true;
        //}
        for(int phys = 0; phys < physics; phys++){
            //{Handle input
            quit = updateMouse();
            handleInput(tanks[0]);
            if(pause){
                std::cout << "pausing";
                pause = false;
                pauseduration = SDL_GetTicks();
                if(pauseMenu()){//pause menu returns true if returning to main menu, otherwise continue
                    tanks.clear();
                    shapes.clear();
                    particlelines.clear();
                    return 1;
                }
                lastpause = SDL_GetTicks();
                pauseduration = lastpause - pauseduration;
                recentpause = true;
            }
            tanks[0]->pointTo( mouseX*1.0, mouseY*1.0 );
            tanks[0]->step();
            fire(LmouseState, RmouseState, tanks[0], &projectiles);
            //}
            //enemy AI
            for(int i=1; i<tanks.size(); i++){
                double targx = tanks[0]->getX();
                double targy = tanks[0]->getY();
                if(cansee(i, 0, &targx, &targy)){
                    tanks[i]->settargetvel(tanks[0]->getVel());
                    tanks[i]->pointTo( targx, targy );
//                    tanks[i]->pointTo( tanks[0]->getX(), tanks[0]->getY() );
                    tanks[i]->step();
                    if(sqrt(pow((targx-tanks[i]->getX()), 2)+pow((targy-tanks[i]->getY()), 2))>100){
                        tanks[i]->accelerate(100);
                        tanks[i]->brake(0);
                    }else{
                        tanks[i]->accelerate(0);
                        tanks[i]->brake(100);
                    }
                    fire(true, false, tanks[i], &projectiles);
                } else {
                    tanks[i]->settargetvel(0.0);
                    if(tanks[i]->hasseentarget()){
                        tanks[i]->accelerate(100);
                        tanks[i]->brake(0);
                    } else {
                        tanks[i]->accelerate(0);
                        tanks[i]->brake(100);
                    }
                    tanks[i]->step();
                }
//                std::cout << "VISIBLE!!!\n";
            }
        }
        //{Set camera coordinates
        if(camX==0){
            camX=((tanks[0]->getX()+mouseX)/2)-SCREEN_WIDTH/2.0;
        }
        if(camY==0){
            camY=((tanks[0]->getY()+mouseY)/2)-SCREEN_HEIGHT/2.0;
        }
        if(camX<-100)
            camX=-100;
        else if (camX>mapwidth+100-SCREEN_WIDTH)
            camX=mapwidth+100-SCREEN_WIDTH;
        if(camY<-100)
            camY=-100;
        else if (camY>mapheight+100-SCREEN_HEIGHT)
            camY=mapheight+100-SCREEN_HEIGHT;
        SDL_GetMouseState( &mouseX, &mouseY );
        mouseX+=camX;
        mouseY+=camY;
        //}
        //render everything
        //draw shape outlines
        SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0xFF );
        for(int i=0;i<shapes.size();i++){
            SCROLL_RenderDrawLine( gRenderer, shapes[i]->x[shapes[i]->x.size()-1], shapes[i]->y[shapes[i]->x.size()-1], shapes[i]->x[0], shapes[i]->y[0] );
            for(int j=0;j<shapes[i]->x.size()-1;j++)
                SCROLL_RenderDrawLine( gRenderer, shapes[i]->x[j], shapes[i]->y[j], shapes[i]->x[j+1], shapes[i]->y[j+1] );
        }
        //step projectiles
		for(int i = 0; i < projectiles.size(); i++){
            bool remove = stepProjectile(projectiles[i]);
            if(remove){
                projectiles.erase(projectiles.begin()+i);
            }
        }
        if(particleEffects){
        for(int i = 0; i < particlelines.size(); i++){
            ParticleLine temp = particlelines[i];
            SDL_SetRenderDrawColor( gRenderer, temp.r, temp.g, temp.b, temp.a);
            SCROLL_RenderDrawLine( gRenderer, temp.x1, temp.y1, temp.x2, temp.y2);
            temp.r += 0.5*30*stepSize*temp.dr*200;
            temp.g += 0.5*30*stepSize*temp.dg*200;
            temp.b += 0.5*30*stepSize*temp.db*200;
            temp.a += 0.5*30*stepSize*temp.da*200;
            temp.t += 0.5*30*stepSize*temp.dt*200;
            particlelines[i] = temp;
            if(temp.t >= 0xFF)
                particlelines.erase(particlelines.begin()+i);
        }
        }else{
            particlelines = *(new std::vector<ParticleLine>);
        }
        //render tanks
		for(int i=0; i<tanks.size(); i++){
            tanks[i]->render();
		}
		//render headsup
		//health and shield
		SDL_Rect healthRect = { 25, 25, 300, 10 };//grey back
		SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0x1F );
		SDL_RenderFillRect( gRenderer, &healthRect );
		healthRect = { 25, 25, 300.0*(tanks[0]->getHealth()/tanks[0]->getMaxHealth()), 10 };//health
		SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xAF );
		SDL_RenderFillRect( gRenderer, &healthRect );
        healthRect = { 25, 25, 300.0*(tanks[0]->getShield()/tanks[0]->getMaxShield()), 10 };//shield
		SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0xFF, 0x6F );
		SDL_RenderFillRect( gRenderer, &healthRect );
		//show reloading
		healthRect = { 350, 25, 100, 10 };//grey back
		SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0x1F );
		SDL_RenderFillRect( gRenderer, &healthRect );
        healthRect = { 350, 25, 100.0*(tanks[0]->getPrimaryReload()/tanks[0]->getPrimaryROF()), 10 };//primary
		SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xAF );
		SDL_RenderFillRect( gRenderer, &healthRect );
//		healthRect = { 350, 25, 100.0*(tanks[0]->getSecondaryReload()/tanks[0]->getSecondaryROF()), 10 };//secondary
//		SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0xFF, 0x6F );
//		SDL_RenderFillRect( gRenderer, &healthRect );

		//render lil health bars
        for(int i=0;i<tanks.size();i++){
            SDL_Rect healthRect = { tanks[i]->getX()-camX-50, tanks[i]->getY()-camY-50, 100, 5 };//grey back
            SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0x1F );
            SDL_RenderFillRect( gRenderer, &healthRect );
            healthRect = { tanks[i]->getX()-camX-50, tanks[i]->getY()-camY-50, 100.0*(tanks[i]->getHealth()/tanks[i]->getMaxHealth()), 5 };//health
            SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xAF );
            SDL_RenderFillRect( gRenderer, &healthRect );
            healthRect = { tanks[i]->getX()-camX-50, tanks[i]->getY()-camY-50, 100.0*(tanks[i]->getShield()/tanks[i]->getMaxShield()), 5 };//shield
            SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0xFF, 0x6F );
            SDL_RenderFillRect( gRenderer, &healthRect );
        }
		//render to screen
		SDL_RenderPresent( gRenderer );
		camX=0;
		camY=0;
		//clear
//		if(damagefx)
//            SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
//		else
            SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
//        damagefx = false;
		SDL_RenderClear( gRenderer );
        //stay under framrate cap
		if(SDL_GetTicks()-frameTimer < TICKS_PER_FRAME)
            SDL_Delay(TICKS_PER_FRAME-(SDL_GetTicks()-frameTimer));
        //console log
        std::cout << "FPS: " << frames.size() << "\n";
        frameCount++;
        std::cout << "Frame count: " << frameCount << "\n";
        std::cout << "Particles: " << particlelines.size() << "\n";
//        std::cout << "Projectile count: " << projectiles.size() << "\n";

	}
	return 0;
}

void addButton(std::vector<Shape*>* toadd, double xpos, double ypos, double width, double height){
    Shape* shape = new Shape;
    std::vector<double>* x = new std::vector<double>;
    std::vector<double>* y = new std::vector<double>;
    x->push_back(xpos-width/2);
    x->push_back(xpos-width/2);
    x->push_back(xpos+width/2);
    x->push_back(xpos+width/2);
    y->push_back(ypos-height/2);
    y->push_back(ypos+height/2);
    y->push_back(ypos-height/2);
    y->push_back(ypos+height/2);
    sortpoints(x, y);
    shape->x = *x;
    shape->y = *y;
    toadd->push_back(shape);
    shape = NULL;
}

uint8_t mainMenu(){
    //Add menu
    std::cout << "showing menu\n";
    std::vector<Shape*> buttons;
    bool atMenu = true;
    addButton(&buttons, SCREEN_WIDTH/2, SCREEN_HEIGHT/4, SCREEN_WIDTH/2, SCREEN_HEIGHT/10);
    addButton(&buttons, SCREEN_WIDTH/2, SCREEN_HEIGHT*3/4, SCREEN_WIDTH/2, SCREEN_HEIGHT/10);
    //{render buttons
    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
	SDL_RenderClear( gRenderer );
    SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0xFF );
    for(int i=0;i<buttons.size();i++){
        SDL_RenderDrawLine( gRenderer, buttons[i]->x[buttons[i]->x.size()-1], buttons[i]->y[buttons[i]->x.size()-1], buttons[i]->x[0], buttons[i]->y[0] );
        for(int j=0;j<buttons[i]->x.size()-1;j++)
            SDL_RenderDrawLine( gRenderer, buttons[i]->x[j], buttons[i]->y[j], buttons[i]->x[j+1], buttons[i]->y[j+1] );
    }
    std::string text = "Play Game";
    SDL_Color textColour = {0, 0, 0};
    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont, text.c_str(), textColour );
    SDL_Texture* mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface );
    SDL_Rect temp = {(SCREEN_WIDTH-textSurface->w)/2, SCREEN_HEIGHT/4-textSurface->h/2, textSurface->w, textSurface->h};
    SDL_FreeSurface( textSurface );
	SDL_RenderCopyEx( gRenderer, mTexture, NULL, &temp, 0, NULL, SDL_FLIP_NONE);

	text = "Quit";
    //textColour = {0, 0, 0};
    textSurface = TTF_RenderText_Solid( gFont, text.c_str(), textColour );
    mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface );
    temp = {(SCREEN_WIDTH-textSurface->w)/2, SCREEN_HEIGHT*3/4-textSurface->h/2, textSurface->w, textSurface->h};
    SDL_FreeSurface( textSurface );
	SDL_RenderCopyEx( gRenderer, mTexture, NULL, &temp, 0, NULL, SDL_FLIP_NONE);
    SDL_RenderPresent( gRenderer );
    //}
    bool escstate = false;
    while(atMenu){
        if(updateMouse())//updateMouse returns true if quit signal is sent
            return 0;
        SDL_GetMouseState( &mouseX, &mouseY );
        if(LmouseClick)
            for(int i=0; i<buttons.size();i++){
                if(isInShape(mouseX, mouseY, *buttons[i])){
                    switch (i){
                        case 0:
                            atMenu=false;
                        break;
                        case 1:
                            return 0;
                        break;
                    }
                }
            }
        if(!keys[ SDL_SCANCODE_ESCAPE] && escstate)//when escape key released
                return 0;//quit game
        escstate=keys[ SDL_SCANCODE_ESCAPE];
        SDL_RenderPresent( gRenderer );//nothing moves, but will prevent screen from going glitchy when dragged
    }
    loadSettings("data/game/settings.txt");
    loadTankTemplates("data/game/tanktemplates.txt");
	loadTanks("data/game/tanks.txt");
	setMap("data/game/map1.txt");
	return 2;//go back and start game
}

bool pauseMenu(){
    bool loop = true;
    //const Uint8* keys = SDL_GetKeyboardState( NULL );
    while(loop){
        SDL_PumpEvents();
        if(!keys[SDL_SCANCODE_ESCAPE])
            loop = false;
    }
    loop = true;
    bool escstate = false;

    std::vector<Shape*> buttons;
    addButton(&buttons, SCREEN_WIDTH/2, SCREEN_HEIGHT/4, SCREEN_WIDTH/2, SCREEN_HEIGHT/10);
    addButton(&buttons, SCREEN_WIDTH/2, SCREEN_HEIGHT*3/4, SCREEN_WIDTH/2, SCREEN_HEIGHT/10);
    //{render buttons
    SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
	SDL_RenderClear( gRenderer );
    SDL_SetRenderDrawColor( gRenderer, 0x00, 0x00, 0x00, 0xFF );
    for(int i=0;i<buttons.size();i++){
        SDL_RenderDrawLine( gRenderer, buttons[i]->x[buttons[i]->x.size()-1], buttons[i]->y[buttons[i]->x.size()-1], buttons[i]->x[0], buttons[i]->y[0] );
        for(int j=0;j<buttons[i]->x.size()-1;j++)
            SDL_RenderDrawLine( gRenderer, buttons[i]->x[j], buttons[i]->y[j], buttons[i]->x[j+1], buttons[i]->y[j+1] );
    }
    std::string text = "Return to Main Menu";
    SDL_Color textColour = {0, 0, 0};
    SDL_Surface* textSurface = TTF_RenderText_Solid( gFont, text.c_str(), textColour );
    SDL_Texture* mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface );
    SDL_Rect temp = {(SCREEN_WIDTH-textSurface->w)/2, SCREEN_HEIGHT/4-textSurface->h/2, textSurface->w, textSurface->h};
    SDL_FreeSurface( textSurface );
	SDL_RenderCopyEx( gRenderer, mTexture, NULL, &temp, 0, NULL, SDL_FLIP_NONE);

	text = "Resume Game";
    //textColour = {0, 0, 0};
    textSurface = TTF_RenderText_Solid( gFont, text.c_str(), textColour );
    mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface );
    temp = {(SCREEN_WIDTH-textSurface->w)/2, SCREEN_HEIGHT*3/4-textSurface->h/2, textSurface->w, textSurface->h};
    SDL_FreeSurface( textSurface );
	SDL_RenderCopyEx( gRenderer, mTexture, NULL, &temp, 0, NULL, SDL_FLIP_NONE);
    SDL_RenderPresent( gRenderer );
    //}
    std::cout << "paused";
    while(loop){
        if(updateMouse())//updateMouse returns true if quit signal is sent
            return true;
        SDL_GetMouseState( &mouseX, &mouseY );
        if(LmouseClick)
            for(int i=0; i<buttons.size();i++){
                if(isInShape(mouseX, mouseY, *buttons[i])){
                    switch (i){
                        case 0:
                            return true;
                        break;
                        case 1:
                            return false;
                        break;
                    }
                }
            }
        SDL_RenderPresent( gRenderer );
//        const Uint8* keys = SDL_GetKeyboardState( NULL );
        if(!keys[ SDL_SCANCODE_ESCAPE] && escstate)//when escape key released
                    return false;//continue game
        escstate=keys[ SDL_SCANCODE_ESCAPE];
    }
}

bool loadSettings(char* filename){
    std::ifstream infile(filename);
    std::string line;
    while (std::getline(infile, line)){//read from file
        if(line.length()!=0){
            if(line.find("skipMenu")!=std::string::npos){
                if(line.substr(line.find("-")+1)=="true")
                    return true;
            }else if(line.find("particleEffects")!=std::string::npos){
                if(line.substr(line.find("-")+1)=="true")
                    particleEffects=true;
            }
        }
    }
    return false;
}

void loadTankTemplates(char* filename){
    Tank t = *(new Tank("unnamed", 0, 0, 0));
    std::ifstream infile(filename);
    std::string line;
    //{temporary values for template loading
    double power;
	double brakeforce;
	double maxvel;
    double mass;

    double primaryProjectileSpeed;
    double secondaryProjectileSpeed;
    int primaryROF;
    int secondaryROF;
    double pspread;
    double sspread;
    int pburst;
    int sburst;
    double primaryDamage;
    double secondaryDamage;

    double length;
    double width;
	double turretradius;
	double barrellength;
	double barrelwidth;
    double pprojlength;
    double pprojwidth;
    double sprojlength;
    double sprojwidth;

    double maxHealth;
    double maxShield;
    double shieldRegen;
    int shieldDelay;
    double health;
    double shield;

    std::string bodypath = "data/graphics/body.png";
    std::string turretpath = "data/graphics/turret.png";
    std::string barrelpath = "data/graphics/barrel.png";
    std::string pprojpath = "data/graphics/primaryprojectile.png";
    std::string sprojpath = "data/graphics/secondaryprojectile.png";

    ParticleLine primary;
    ParticleLine secondary;
    //}
    while (std::getline(infile, line)){//read from file
        if(line.length()!=0){
            if(line.at(0)=='n'){//set name
                t.positionReset(line.substr(1), 0, 0, 0, true);
            }else if(line.at(0)=='a'){//add template and start a new one
                t.setDimensions(length, width, turretradius, barrellength, barrelwidth, pprojlength, pprojwidth, sprojlength, sprojwidth);
                t.setOther(power, brakeforce, maxvel, mass);
                t.setWeapons(primaryDamage, secondaryDamage, primaryProjectileSpeed, secondaryProjectileSpeed, primaryROF, secondaryROF, pspread, sspread, pburst, sburst, primary, secondary);
                t.setHealth(maxHealth, maxShield, shieldRegen, shieldDelay);
                t.loadLook(bodypath, turretpath, barrelpath, pprojpath, sprojpath, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
                tankTemplates.push_back(t);
                t = *(new Tank("unnamed", 0, 0, 0));
            }else if(line.at(0)=='o'){
                if(line.at(1)=='p'){
                    power = atof(line.substr(2).c_str());
                }else if(line.at(1)=='b'){
                    brakeforce = atof(line.substr(2).c_str());
                }else if(line.at(1)=='v'){
                    maxvel = atof(line.substr(2).c_str());
                }else if(line.at(1)=='m'){
                    mass = atof(line.substr(2).c_str());
                }
            }else if(line.at(0)=='w'){
                if(line.at(1)=='p'){
                    if(line.at(2)=='s'){
                        primaryProjectileSpeed=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='r'){
                        primaryROF=atoi(line.substr(3).c_str());
                    }else if(line.at(2)=='a'){
                        pspread=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='b'){
                        pburst=atoi(line.substr(3).c_str());    //add in particle effect after here
                    }else if(line.at(2)=='d'){
                        primaryDamage=atof(line.substr(3).c_str());
                    }
                }else if(line.at(1)=='s'){
                    if(line.at(2)=='s'){
                        secondaryProjectileSpeed=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='r'){
                        secondaryROF=atoi(line.substr(3).c_str());
                    }else if(line.at(2)=='a'){
                        sspread=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='b'){
                        sburst=atoi(line.substr(3).c_str());    //add in particle effect after here
                    }else if(line.at(2)=='d'){
                        secondaryDamage=atof(line.substr(3).c_str());
                    }
                }
            }else if(line.at(0)=='d'){
                if(line.at(1)=='l'){
                    length=atof(line.substr(2).c_str());
                }else if(line.at(1)=='w'){
                    width=atof(line.substr(2).c_str());
                }else if(line.at(1)=='r'){
                    turretradius=atof(line.substr(2).c_str());
                }else if(line.at(1)=='b'){
                    if(line.at(2)=='l'){
                        barrellength=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='w'){
                        barrelwidth=atof(line.substr(3).c_str());
                    }
                }else if(line.at(1)=='p'){
                    if(line.at(2)=='l'){
                        pprojlength=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='w'){
                        pprojwidth=atof(line.substr(3).c_str());
                    }
                }else if(line.at(1)=='s'){
                    if(line.at(2)=='l'){
                        sprojlength=atof(line.substr(3).c_str());
                    }else if(line.at(2)=='w'){
                        sprojwidth=atof(line.substr(3).c_str());
                    }
                }
            }else if(line.at(0)=='h'){
                if(line.at(1)=='h'){
                    maxHealth=atof(line.substr(2).c_str());
                    health=maxHealth;
                }else if(line.at(1)=='s'){
                    maxShield=atof(line.substr(2).c_str());
                    shield=maxShield;
                }else if(line.at(1)=='r'){
                    shieldRegen=atof(line.substr(2).c_str());
                }else if(line.at(1)=='d'){
                    shieldDelay=atoi(line.substr(2).c_str());
                }
            }else if(line.at(0)=='l'){
                if(line.at(1)=='b'){
                    bodypath=line.substr(2);
                }else if(line.at(1)=='t'){
                    turretpath=line.substr(2);
                }else if(line.at(1)=='a'){
                    barrelpath=line.substr(2);
                }else if(line.at(1)=='p'){
                    pprojpath=line.substr(2);
                }else if(line.at(1)=='s'){
                    sprojpath=line.substr(2);
                }
            }else if(line.at(0)=='c'){
                t.setIsCircle(true);
            }else if(line.at(0)=='p'){//particle effect
                if(line.at(1)=='p'){//primary weapon
                    switch(line.at(2)){
                        case 'r':
                            primary.r=atof(line.substr(3).c_str());
                        break;
                        case 'g':
                            primary.g=atof(line.substr(3).c_str());
                        break;
                        case 'b':
                            primary.b=atof(line.substr(3).c_str());
                        break;
                        case 'a':
                            primary.a=atof(line.substr(3).c_str());
                        break;
                        case 't':
                            primary.t=atof(line.substr(3).c_str());
                        break;
                    }
                    if(line.at(2)=='d'){
                        switch(line.at(3)){
                            case 'r':
                                primary.dr=atof(line.substr(4).c_str());
                            break;
                            case 'g':
                                primary.dg=atof(line.substr(4).c_str());
                            break;
                            case 'b':
                                primary.db=atof(line.substr(4).c_str());
                            break;
                            case 'a':
                                primary.da=atof(line.substr(4).c_str());
                            break;
                            case 't':
                                primary.dt=atof(line.substr(4).c_str());
                            break;
                        }
                    }
                }else if(line.at(1)=='s'){
                    switch(line.at(2)){
                        case 'r':
                            secondary.r=atof(line.substr(3).c_str());
                        break;
                        case 'g':
                            secondary.g=atof(line.substr(3).c_str());
                        break;
                        case 'b':
                            secondary.b=atof(line.substr(3).c_str());
                        break;
                        case 'a':
                            secondary.a=atof(line.substr(3).c_str());
                        break;
                        case 't':
                            secondary.t=atof(line.substr(3).c_str());
                        break;
                    }
                    if(line.at(2)=='d'){
                        switch(line.at(3)){
                            case 'r':
                                secondary.dr=atof(line.substr(4).c_str());
                            break;
                            case 'g':
                                secondary.dg=atof(line.substr(4).c_str());
                            break;
                            case 'b':
                                secondary.db=atof(line.substr(4).c_str());
                            break;
                            case 'a':
                                secondary.da=atof(line.substr(4).c_str());
                            break;
                            case 't':
                                secondary.dt=atof(line.substr(4).c_str());
                            break;
                        }
                    }
                }
            }
        }
    }
}

void loadTanks(char* filename){
    std::ifstream infile(filename);
    std::string line;
    Tank* t = new Tank();
    double x;
    double y;
    double r=0;
    bool templated = false;
    while (std::getline(infile, line)){
        if(line.length()!=0){
            if(line.at(0)=='n'){
                for(int i=0;i<tankTemplates.size();i++){
                    if(tankTemplates[i].getName()==line.substr(1)){
                        *t = tankTemplates[i];
                        templated = true;
                    }
                }
                if(!templated){
                    std::cout << "Name " << line.substr(1) << " not found!\n";
                }
            }else if(line.at(0)=='a'){
                if(templated){
                    t->positionReset("", x, y, r, true);
                    tanks.push_back(t);
                }else{
                    std::cout << "Error: No template loaded\n";
                }
                t = new Tank();
            }else if(line.at(0)=='x'){
                x = atof(line.substr(1).c_str());
                if(x<0)
                    x = SCREEN_WIDTH + x;
            }else if(line.at(0)=='y'){
                y = atof(line.substr(1).c_str());
                if(y<0)
                    y = SCREEN_HEIGHT + y;
            }else if(line.at(0)=='r'){
                r = atof(line.substr(1).c_str());
            }
        }
    }
    for(int i=0;i<tanks.size();i++){
        tanks[i]->setIndex(i);
	}
}

void setMap(char* filename){
    int* dimensions = loadMap(&shapes, filename);
	mapwidth = dimensions[0];   //set map dimensions
	mapheight = dimensions[1];

	//set barriers
	Shape* shape = new Shape;
	std::vector<double>* x = new std::vector<double>;
	std::vector<double>* y = new std::vector<double>;
	//top barrier
    x = new std::vector<double>;
    y = new std::vector<double>;
    x->push_back(-250);
    x->push_back(mapwidth+250);
    x->push_back(mapwidth+250);
    x->push_back(-250);
    y->push_back(-250);
    y->push_back(-250);
    y->push_back(0);
    y->push_back(0);
    sortpoints(x, y);
    shape = new Shape;
    shape->x = *x;
    shape->y = *y;
    shapes.push_back(shape);

    //bottom barrier
    x = new std::vector<double>;
    y = new std::vector<double>;
    x->push_back(-250);
    x->push_back(mapwidth+250);
    x->push_back(mapwidth+250);
    x->push_back(-250);
    y->push_back(mapheight+250);
    y->push_back(mapheight+250);
    y->push_back(mapheight);
    y->push_back(mapheight);
    sortpoints(x, y);
    shape = new Shape;
    shape->x = *x;
    shape->y = *y;
    shapes.push_back(shape);

    //left barrier
    x = new std::vector<double>;
    y = new std::vector<double>;
    x->push_back(-250);
    x->push_back(0);
    x->push_back(0);
    x->push_back(-250);
    y->push_back(-250);
    y->push_back(-250);
    y->push_back(mapheight+250);
    y->push_back(mapheight+250);
    sortpoints(x, y);
    shape = new Shape;
    shape->x = *x;
    shape->y = *y;
    shapes.push_back(shape);

    //left barrier
    x = new std::vector<double>;
    y = new std::vector<double>;
    x->push_back(mapwidth);
    x->push_back(mapwidth+250);
    x->push_back(mapwidth+250);
    x->push_back(mapwidth);
    y->push_back(-250);
    y->push_back(-250);
    y->push_back(mapheight+250);
    y->push_back(mapheight+250);
    sortpoints(x, y);
    shape = new Shape;
    shape->x = *x;
    shape->y = *y;
    shapes.push_back(shape);
}

int* loadMap(std::vector<Shape*>* shapestemp, char* filename){
    int* dimensions = new int[2];
    std::vector<double>* x = new std::vector<double>;
    std::vector<double>* y = new std::vector<double>;
    Shape* shape;

    std::ifstream infile(filename);
    std::string line;
    while (std::getline(infile, line)){//read from file
        if(line.length()!=0){
            if(line.at(0)=='w')//map width
                dimensions[0] = atoi( line.substr(1).c_str() );
            else if(line.at(0)=='h')//map height
                dimensions[1] = atoi( line.substr(1).c_str() );
            else if(line.at(0)=='x')//x coordinate of corner
                x->push_back(atoi(line.substr(1).c_str()));
            else if(line.at(0)=='y')//y coordinate of corner
                y->push_back(atoi(line.substr(1).c_str()));
            else if(line.at(0)=='s'){//new shape
                if(x->size()==y->size() && x->size()>>1){
                sortpoints(x, y);
                shape = new Shape;
                shape->x = *x;
                shape->y = *y;
                shapestemp->push_back(shape);
                }
                x = new std::vector<double>;
                y = new std::vector<double>;
            }
        }
    }
    return dimensions;
}

void fire(bool pfire, bool sfire, Tank* tank, std::vector<Projectile*>* projectiles){
    if(pfire && tank->primaryReloaded()){
        for(int i=0; i<tank->getPburst(); i++){
            Projectile* t = new Projectile;
            projectiles->push_back(t);
            tank->shootPrimary(t);
        }
    }
   	if(sfire && tank->secondaryReloaded()){
        for(int i=0; i<tank->getSburst(); i++){
            Projectile* t = new Projectile;
            projectiles->push_back(t);
            tank->shootSecondary(t);
        }
    }
}

bool stepProjectile(Projectile* proj){
    //render line
    bool ret = false;
    ParticleLine part = proj->traileffect;
    part.id=effectIDs;
    effectIDs++;
    //std::cout << sqrt(pow(proj->xvel*stepSize, 2)+pow(proj->yvel*stepSize, 2)) << "\n";
    if((proj->dist+1)*sqrt(pow(proj->xvel*stepSize, 2)+pow(proj->yvel*stepSize, 2)) > traileffectprescision){
        proj->dist=0;
    }else{
        for(int i=particlelines.size()-1;i>=0;i--)
            if(particlelines[i].id==proj->lastid){
                particlelines.erase(particlelines.begin()+i);
                i=-1;
            }
        }
    if(particleEffects){
    part.x1 = proj->x-proj->dist*proj->xvel*stepSize;
    part.y1 = proj->y-proj->dist*proj->yvel*stepSize;
    part.x2 = proj->x+proj->xvel*stepSize;
    part.y2 = proj->y+proj->yvel*stepSize;
    }
    proj->dist++;
//    part.r = 0xFF;
//    part.dg = 3;
//    part.db = 3;
//    part.a = 0xFF;
//    part.dt = 3;
//    if(proj->timer < 0xFF){
//        SDL_SetRenderDrawColor( gRenderer, 0xFF, proj->timer, proj->timer, 0xFF );
//        SCROLL_RenderDrawLine( gRenderer, proj->tx, proj->ty, proj->x, proj->y );
//        proj->timer+=200.0;
//    }
    //detect collision
	for(int i=0; i<tanks.size(); i++){
        Shape temp = tanks[i]->getShape();
        if((ret == false)&&(passedovershape(proj->x, proj->y, proj->x+proj->xvel*stepSize, proj->y+proj->yvel*stepSize, temp) || isInShape(proj->x, proj->y, temp))){
//            if(i==0)
//                damagefx = true;
            std::cout << "Tank " << i << " hit by a projectile\n";
            tanks[i]->takeDamage(proj->damage);
            ret = true;
            double xt = proj->x;
            double yt = proj->y;
            while(!(passedovershape(proj->x, proj->y, xt, yt, temp) || isInShape(proj->x, proj->y, temp))){
                xt += proj->xvel*stepSize*streakrenderres;
                yt += proj->yvel*stepSize*streakrenderres;
            }
            if(particleEffects){
            part.x2 = xt;
            part.y2 = yt;
            }
        }
	}
    for(int i=0; i<shapes.size(); i++){
        Shape* temp = shapes[i];
        if((ret == false)&&(passedovershape(proj->x, proj->y, proj->x+proj->xvel*stepSize, proj->y+proj->yvel*stepSize, *temp) || isInShape(proj->x, proj->y, *temp))){
            std::cout << "Shape " << i << " hit by a projectile\n";
            ret = true;
            //find point where shape was hit
            double xt = proj->x;
            double yt = proj->y;
            while(!(passedovershape(proj->x, proj->y, xt, yt, *temp) || isInShape(proj->x, proj->y, *temp))){
                xt += proj->xvel*stepSize*streakrenderres;
                yt += proj->yvel*stepSize*streakrenderres;
            }
            part.x2 = xt;
            part.y2 = yt;
        }
	}
	if(!ret){
	//render projectile
    SDL_Rect renderposition = {proj->x+proj->xvel*stepSize-proj->width/2-camX, proj->y+proj->yvel*stepSize-proj->length/2-camY, proj->width, proj->length};						//x-width/2 is used, so that the x and y coordinates refer to the center of the tank
	SDL_RenderCopyEx( gRenderer, proj->look, &proj->clip, &renderposition, proj->angle+90, NULL, SDL_FLIP_NONE);
	}
    proj->x += proj->xvel*stepSize;
    proj->y += proj->yvel*stepSize;
    //maths to find if projectile will cross screen
    //if not (going to cross screen and going towards screen
    /*int visualX=proj->x-camX;
    int visualY=proj->y-camY;
    if(visualX < 0 || visualX > SCREEN_WIDTH || visualY < 0 || visualY > SCREEN_HEIGHT){    //off the screen
        if(visualY > SCREEN_HEIGHT/2){  //below centre of the screen
            if(visualX > SCREEN_WIDTH/2){   //bottom right
                if(!(yfromx(SCREEN_WIDTH, visualX, visualY, proj->xvel, proj->yvel) > 0 && yfromx(0, visualX, visualY, proj->xvel, proj->yvel) < SCREEN_HEIGHT && proj->xvel < 0 && proj->yvel < 0))
                    ret = true;
            }else{  //bottom left
                if(!(yfromx(SCREEN_WIDTH, visualX, visualY, proj->xvel, proj->yvel) < SCREEN_HEIGHT && yfromx(0, visualX, visualY, proj->xvel, proj->yvel) > 0 && proj->xvel > 0 && proj->yvel < 0))
                    ret = true;
            }
        }else{  //above centre of the screen
            if(proj->x > SCREEN_WIDTH/2){   //top right
                if(!(yfromx(SCREEN_WIDTH, visualX, visualY, proj->xvel, proj->yvel) < SCREEN_HEIGHT && yfromx(0, visualX, visualY, proj->xvel, proj->yvel) > 0 && proj->xvel < 0 && proj->yvel > 0))
                    ret = true;
            }else{  //top left
                if(!(yfromx(SCREEN_WIDTH, visualX, visualY, proj->xvel, proj->yvel) > 0 && yfromx(0, visualX, visualY, proj->xvel, proj->yvel) < SCREEN_HEIGHT && proj->xvel > 0 && proj->yvel > 0))
                    ret = true;
            }
        }
    }*/
//    if(proj->timer < 0xFF)
//        return false;
    if(particleEffects)
        particlelines.push_back(part);
    proj->lastid=part.id;
    return ret;
}

bool cansee(int tank1, int tankn, double* targx, double* targy){
    //Find angle and distance to tank
    //Rotate clockwise from angle and check if collision with given tank and nothing else
    //same but clockwise
    double x = tanks[tank1]->getX();    //coordinates of tank
    double y = tanks[tank1]->getY();
    double tx = tanks[tankn]->getX();   //coordinates of target
    double ty = tanks[tankn]->getY();
//   	bool visible = false;
   	bool tvisible = true;   //keeps track of whether the target is visible
   	for(int i=0; i<tanks.size(); i++){  //check through all shapes that are not the tank or target; if none are blocking the view tvisible is left true
        if(i!=tankn && i!=tank1){
            Shape temp = tanks[i]->getShape();
            if((tvisible == true)&&(passedovershape(x, y, tx, ty, temp) || isInShape(x, y, temp))){
                tvisible = false;
            }
        }
	}
    for(int i=0; i<shapes.size(); i++){
        Shape* temp = shapes[i];
        if((tvisible == true)&&(passedovershape(x, y, tx, ty, *temp) || isInShape(x, y, *temp))){
            tvisible = false;
        }
	}
	double angle = atan2(y, x, ty, tx); //set angle to target
	if(tvisible == true){   //if target is visible return true
        return true;
	}
	double tangle = angle;  //angle changed to check if target is visible
	bool run = true;    //variable for while loop
	double dist;    //distance to the target at tangle
	int checks = 0; //track the number of angles checked
	double acdist = distanceto(x, y, angle, tankn, 0, 10000);   //last value is the maximum range
	while(run){
        checks++;   //increment the counter
        tangle+=scanangleincrement; //increment tangle
        dist = distanceto(x, y, tangle, tankn, acdist-30, acdist+30);   //find exact distance to target
        double c = 0 - cos(tangle); //set cos and sin of angle
        double s = sin(tangle);
        tx = x + c * dist;  //coordinates of edge of target at tangle from the tank
        ty = y + s * dist;
//        std::cout << "acdist: " << acdist << "\ndistance: " << dist << "\nangle: " << tangle << "\nx: " << tx << "\ny: " << ty << "\n";
        if(dist == 0)   //if distance is 0, target is not found at angle tangle from the tank within the given range
            run = false;
        else{
        tvisible = true;    //perform the same check as before but with a different angle
           	for(int i=0; i<tanks.size(); i++){
                if(i!=tankn && i!=tank1){
                    Shape temp = tanks[i]->getShape();
                    if((tvisible == true)&&(passedovershape(x, y, tx, ty, temp) || isInShape(x, y, temp))){
                        tvisible = false;
                    }
                }
            }
            for(int i=0; i<shapes.size(); i++){
                Shape* temp = shapes[i];
                if((tvisible == true)&&(passedovershape(x, y, tx, ty, *temp) || isInShape(x, y, *temp))){
                    tvisible = false;
                }
            }
        if(tvisible == true)
            run = false;    //break the loop
        }
	}
	double xpos;
	double ypos;
	double ang1 = tangle;
	if(tvisible){
        impactcoords(x, y, tangle, tankn, acdist-30, acdist+30, &xpos, &ypos);  //save coordinates of target that are visible
	}
	bool vispos = tvisible;
	tangle = angle; //reset tangle
	run = true; //repeat the above but in the opposite direction (clockwise as opposed to anti clockwise)
	while(run){
        checks++;
        tangle-=scanangleincrement;
        dist = distanceto(x, y, tangle, tankn, acdist-30, acdist+30);
        double c = 0 - cos(tangle);
        double s = sin(tangle);
        tx = x + c * dist;
        ty = y + s * dist;
//        std::cout << "distance: " << dist << "\nangle: " << tangle << "\nx: " << tx << "\ny: " << ty << "\n";
        if(dist == 0)
            run = false;
        else{
        tvisible = true;
           	for(int i=0; i<tanks.size(); i++){
                if(i!=tankn && i!=tank1){
                    Shape temp = tanks[i]->getShape();
                    if((tvisible == true)&&(passedovershape(x, y, tx, ty, temp) || isInShape(x, y, temp))){
                        tvisible = false;
                    }
                }
            }
            for(int i=0; i<shapes.size(); i++){
                Shape* temp = shapes[i];
                if((tvisible == true)&&(passedovershape(x, y, tx, ty, *temp) || isInShape(x, y, *temp))){
                    tvisible = false;
                }
            }
        if(tvisible == true)
            run = false;
        }
	}
	double xneg;
	double yneg;
	if(tvisible){
        impactcoords(x, y, tangle, tankn, acdist-30, acdist+30, &xneg, &yneg);
	}
	bool visneg = tvisible;
	if(vispos && visneg){   //select coordinates based on which are closer to the target
        if(ang1-angle < angle-tangle){
            *targx = xpos;
            *targy = ypos;
        }else{
            *targx = xneg;
            *targy = yneg;
        }
	}else if(vispos){
        *targx = xpos;
        *targy = ypos;
	}else if(visneg){
        *targx = xneg;
        *targy = yneg;
	}
//	std::cout << "CHECKS: " << checks << "\n";
	if(vispos || visneg){   //if target is visible return true
        return true;
    }
    return false;
}

double distanceto(double x, double y, double angle, int tank, double mini, double maxi){
    double dist = mini; //set minimum scanning distance
    double xt = x - cos(angle)*mini;    //set initial x and y coords
    double yt = y + sin(angle)*mini;
    Shape temp = tanks[tank]->getShape();
    while(!(passedovershape(x, y, xt, yt, temp) || isInShape(x, y, temp)) && dist < maxi){  //scan in given direction until past the maximum, or the target is encountered
        dist += 1;
        xt -= cos(angle);
        yt += sin(angle);
    }
    if(dist >= maxi)    //if target was not found return 0, otherwise return the distance
        return 0;
    return dist;
}

void impactcoords(double x, double y, double angle, int tank, double mini, double maxi, double* xpos, double* ypos){
    double dist = mini; //same as distanceto method, but with no return value, and the coordinates of the target if found are assigned to the given pointers
    double xt = x - cos(angle)*mini;
    double yt = y + sin(angle)*mini;
    Shape temp = tanks[tank]->getShape();
    while(!(passedovershape(x, y, xt, yt, temp) || isInShape(x, y, temp)) && dist < maxi){
        dist += 1;
        xt -= cos(angle);
        yt += sin(angle);
    }
    *xpos = xt;
    *ypos = yt;
}

double yfromx(double x, double x1, double y1, double xvel, double yvel){    //return y coordinate on a line at given x coordinate
    return x*yvel/xvel + y1 - x1*yvel/xvel;
}

double yfromxcoords(double x, double x1, double y1, double x2, double y2){
    double m = (y1-y2)/(x1-x2);
    double c = y1 - m * x1;
    return m*x + c;
}

bool passedovershape(double xa, double ya, double xb, double yb, Shape shape){
    for(int i=0;i<shape.x.size();i++){
        int j;
        i == shape.x.size()-1 ? j = 0 : j = i+1;
        if(passedover(xa, ya, xb, yb, shape.x[i], shape.y[i], shape.x[j], shape.y[j])){
            return true;
        }else if(shape.x[i] == shape.x[j]){
            if(passedover(ya, xa, yb, xb, shape.y[i], shape.x[i], shape.y[j], shape.x[j]))
                return true;
        }
    }
    return false;
}

bool passedover(double xa, double ya, double xb, double yb, double x1, double y1, double x2, double y2){
    double ma = (yb-ya)/(xb-xa);
    double m1 = (y2-y1)/(x2-x1);
    double ca = ya - ma * xa;
    double c1 = y1 - m1 * x1;

    double x = (ca-c1)/(m1-ma);
    double y = m1 * x + c1;
    return ((x<xa != x<xb) && (x<x1 != x<x2));
}

void sortpoints(std::vector<double>* xs, std::vector<double>* ys){
//    std::cout << "sortpoints\n";
    int length = xs->size();
    std::vector<double>* x = new std::vector<double>;
    std::vector<double>* y = new std::vector<double>;
    bool mark[length];
    double x0 = 0;
    double y0 = 0;
    for(int i=0;i<length;i++){
//        std::cout << "x0 " << x0 << "\n";
        x0+=xs->at(i);
        y0+=ys->at(i);
        mark[i] = true;
//        std::cout << "xs " << xs->at(i) << "\n";

    }
//    std::cout << "ok\n";
    x0/=length; //middle point
    y0/=length;
//    std::cout << "x0 " << x0 << "\n";
//    std::cout << "length " << length << "\n";
    int i = 0;
    bool endloop = false;
    while(!endloop){
        int smallest = -1;
        for(int j=0;j<length;j++){
            if(mark[j]){
                if(xs->at(j) >= x0){
                    if(smallest == -1)
                        smallest = j;
                    else
                        if(atan((ys->at(j)-y0)/(xs->at(j)-x0)) < atan((ys->at(smallest)-y0)/(xs->at(smallest)-x0)))
                            smallest = j;
                }
            }
        }
        if(smallest == -1)
            endloop = true;
        else{
//            std::cout << "smal " << smallest << "\n";
            x->push_back(xs->at(smallest));
            y->push_back(ys->at(smallest));
//            std::cout << "index " << smallest << " out of length " << length << " marked.\n";
            mark[smallest] = false;
            i++;
        }
    }
//    std::cout << "fine\n";
    for(i;i<length;i++){
        int smallest = -1;
        for(int j=0;j<length;j++){
            if(mark[j]){
                if(xs->at(j) < x0){
                    if(smallest == -1)
                        smallest = j;
                    else
                        if(atan((ys->at(j)-y0)/(xs->at(j)-x0)) < atan((ys->at(smallest)-y0)/(xs->at(smallest)-x0)))
                            smallest = j;
                }
            }
        }
//        std::cout << "smal " << smallest << "\n";
//        if(smallest!=-1){
            x->push_back(xs->at(smallest));
            y->push_back(ys->at(smallest));
//            std::cout << "index " << smallest << " out of length " << length << " marked.\n";
            mark[smallest] = false;
//        }
    }
//    std::cout << "no crash :)\n";
//    std::cout << "wtf!?\n";
    *xs = *x;
    *ys = *y;
}

bool collision(int index, double* gradient, bool* setgradient){
    for(int i=0;i<tanks.size();i++){
        if(i==index)
            ;
        else{
            if(checkcollision(tanks[i]->getShape(), tanks[index]->getShape(), gradient, setgradient))
                return true;
        }
    }
    for(int i=0;i<shapes.size();i++){
        Shape temp = *shapes[i];
        if(checkcollision(temp, tanks[index]->getShape(), gradient, setgradient)){
//            std::cout << "Tank: " << index << "\n";
            return true;
        }
    }
    return false;
}

bool checkcollision(Shape shape1, Shape shape2, double* gradient, bool* setgradient){
//    std::cout << "CHECKCOLLISION\n";
    for(int i=0;i<shape1.x.size();i++){
//        std::cout << "fuck";
        if(isInShape(shape1.x[i], shape1.y[i], shape2))
            return true;
    }
    for(int i=0;i<shape2.x.size();i++){
//        std::cout << "fuck";
        if(isInShape(shape2.x[i], shape2.y[i], shape1)){
            int point1 = findSide(shape2.x[i], shape2.y[i], shape1);
            int point2;
            point1 == shape1.x.size()-1 ? point2 = 0 : point2 = point1 + 1;
            //std::cout << "Side colliding with: " << point1 << " to " << point2 << "\n";
            *setgradient = true;
            *gradient = (shape1.y[point1]-shape1.y[point2])/(shape1.x[point1]-shape1.x[point2]);
            return true;
        }
    }
    return false;
}

bool isInShape(double x, double y, Shape shape){
//    std::cout << "ISINSHAPE\n";
    bool isin = true;
    for(int i=0; i<shape.x.size(); i++){

        int im = i-1;
        if(im<0)
            im=shape.x.size()-1;
        int ip = i+1;
        if(ip==shape.x.size())
            ip=0;
        double Im = atan2(shape.x[i], shape.y[i], shape.x[im], shape.y[im]);
        double Ip = atan2(shape.x[i], shape.y[i], shape.x[ip], shape.y[ip]);
        double IT = atan2(shape.x[i], shape.y[i], x, y);
        if(Ip - Im > PI)
            Ip -= 2.0 * PI;
        if((IT < Im == IT < Ip) && (IT-2.0*PI < Im == IT-2.0*PI < Ip)){ //Sketchy maths that actually works
            isin = false;
        }
    }
//    if(isin)
//        std::cout << "collision\n";
    return isin;
}

double atan2(double x1, double y1, double x2, double y2){
    double t = atan((x1-x2)/(y1-y2));
    if(x2 > x1)
        if(y2 > y1)
            t = PI - t;
        else
            t = 0 - t;
    else
        if(y2 > y1)
            t = PI - t;
        else
            t = 2.0 * PI - t;
    return t;
}

int findSide(double x, double y, Shape shape){
    int length = shape.x.size();
    double nearest = nearestpoint(x, y, shape.x[length-1], shape.y[length-1], shape.x[0], shape.y[0]);
    int point = length-1;
    for(int i=0; i<length-1; i++){
        double temp = nearestpoint(x, y, shape.x[i], shape.y[i], shape.x[i+1], shape.y[i+1]);
        if(temp < nearest){
            nearest = temp;
            point = i;
        }
    }
    return point;
}

double nearestpoint(double xp, double yp, double x1, double y1, double x2, double y2){
    if(x1 == x2)
        return abs(xp-x1);
    if(y1 == y2)
        return abs(yp-y1);
    double as = abs(yp-yfromxcoords(xp, x1, y1, x2, y2));
    double dist;
    double ang = tan((x1-x2)/(y1-y2));
    dist = abs(as / sin(ang));
    return dist;
}

bool updateMouse(){
    SDL_Event e;
    bool quit = false;
    //{Handle input
    LmouseClick = 0;
    RmouseClick = 0;
    while( SDL_PollEvent( &e ) != 0 ){
        if( e.type == SDL_QUIT){
            quit = true;
        }else if( e.type == SDL_MOUSEBUTTONDOWN ){
            if(e.button.button == SDL_BUTTON_LEFT){
                LmouseState = 1;
                LmouseClick = 1;
            } else if( e.button.button == SDL_BUTTON_RIGHT){
                RmouseState = 1;
                RmouseClick = 1;
            }
        } else if( e.type == SDL_MOUSEBUTTONUP ){
            if(e.button.button == SDL_BUTTON_LEFT)
                LmouseState = 0;
            else if(e.button.button == SDL_BUTTON_RIGHT)
                RmouseState = 0;
        }
    }
    //}
    return quit;
}

void handleInput(Tank* player){
	//const Uint8* keys = SDL_GetKeyboardState( NULL );
	if( keys[ SDL_SCANCODE_W ] ){
		player->accelerate(100);
	}else if( keys[ SDL_SCANCODE_S ] ){
		player->accelerate(-100);
	}else{
		player->accelerate(0);
	}
	if( !( keys[ SDL_SCANCODE_A ] && keys[ SDL_SCANCODE_D ] ) ){
		if( keys[ SDL_SCANCODE_A ] ){
			player->turn(-100);
		}else if( keys[ SDL_SCANCODE_D ] ){
			player->turn(100);
		}else{
			player->turn(0);
		}
	}
	if( keys[ SDL_SCANCODE_LSHIFT ] ){
		player->brake(100);
	}else{
		player->brake(0);
	}
    //secret hack
    if( keys[ SDL_SCANCODE_E ] && keys[ SDL_SCANCODE_Q]){
        player->accelerate(10000);
    } else if( keys[ SDL_SCANCODE_Z ] && keys[ SDL_SCANCODE_C]){
        player->accelerate(-10000);
    }
    if( keys[ SDL_SCANCODE_O] )
        slomo = false;
    else if( keys[ SDL_SCANCODE_P] )
        slomo = true;
    if( keys[ SDL_SCANCODE_ESCAPE])
        pause = true;
}

int SCROLL_RenderDrawLine(SDL_Renderer* renderer, int x1, int y1, int x2, int y2){
    return SDL_RenderDrawLine(renderer, x1-camX, y1-camY, x2-camX, y2-camY);
}

//}
