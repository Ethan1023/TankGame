Source and program:
    Copyright 2018 Ethan Corney

Font used:
    Roboto (Copyright 2011 Google Inc. All Rights Reserved.)
    sourced from https://fonts.google.com/specimen/Roboto
    used under Apache License 2.0
